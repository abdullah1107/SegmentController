//
//  ViewController.swift
//  segdemo
//
//  Created by Yogesh Patel on 10/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var img: UIImageView!
    @IBOutlet var lbl: UILabel!
    
    @IBOutlet var seg: UISegmentedControl!
    
    @IBAction func ValueChanged(_ sender: UISegmentedControl) {
        if seg.selectedSegmentIndex == 0 //First
        {
            lbl.text = "Google"
            img.image = #imageLiteral(resourceName: "google")
            
            img.isHidden = false
            lbl.isHidden = false
        }
        else if seg.selectedSegmentIndex == 1 //Second
        {
            img.isHidden = false
            lbl.isHidden = false
            img.image = #imageLiteral(resourceName: "facebook")
            lbl.text = "Facebook"
        }else if seg.selectedSegmentIndex == 2 //Third
        {
            img.isHidden = false
            lbl.isHidden = false
            img.image = #imageLiteral(resourceName: "linkedin")
            lbl.text = "Linkedin"
        }else if seg.selectedSegmentIndex == 3 //Four
        {
            img.isHidden = false
            lbl.isHidden = false
            img.image = #imageLiteral(resourceName: "twitter")
            lbl.text = "Twiiter"
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        img.isHidden = true
        lbl.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

